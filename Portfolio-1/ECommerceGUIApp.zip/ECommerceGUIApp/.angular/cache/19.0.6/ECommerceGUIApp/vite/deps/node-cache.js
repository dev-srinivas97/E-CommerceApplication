import {
  __commonJS
} from "./chunk-3OV72XIM.js";

// node_modules/node-cache/node_modules/clone/clone.js
var require_clone = __commonJS({
  "node_modules/node-cache/node_modules/clone/clone.js"(exports, module) {
    var clone = function() {
      "use strict";
      function _instanceof(obj, type) {
        return type != null && obj instanceof type;
      }
      var nativeMap;
      try {
        nativeMap = Map;
      } catch (_) {
        nativeMap = function() {
        };
      }
      var nativeSet;
      try {
        nativeSet = Set;
      } catch (_) {
        nativeSet = function() {
        };
      }
      var nativePromise;
      try {
        nativePromise = Promise;
      } catch (_) {
        nativePromise = function() {
        };
      }
      function clone2(parent, circular, depth, prototype, includeNonEnumerable) {
        if (typeof circular === "object") {
          depth = circular.depth;
          prototype = circular.prototype;
          includeNonEnumerable = circular.includeNonEnumerable;
          circular = circular.circular;
        }
        var allParents = [];
        var allChildren = [];
        var useBuffer = typeof Buffer != "undefined";
        if (typeof circular == "undefined") circular = true;
        if (typeof depth == "undefined") depth = Infinity;
        function _clone(parent2, depth2) {
          if (parent2 === null) return null;
          if (depth2 === 0) return parent2;
          var child;
          var proto;
          if (typeof parent2 != "object") {
            return parent2;
          }
          if (_instanceof(parent2, nativeMap)) {
            child = new nativeMap();
          } else if (_instanceof(parent2, nativeSet)) {
            child = new nativeSet();
          } else if (_instanceof(parent2, nativePromise)) {
            child = new nativePromise(function(resolve, reject) {
              parent2.then(function(value) {
                resolve(_clone(value, depth2 - 1));
              }, function(err) {
                reject(_clone(err, depth2 - 1));
              });
            });
          } else if (clone2.__isArray(parent2)) {
            child = [];
          } else if (clone2.__isRegExp(parent2)) {
            child = new RegExp(parent2.source, __getRegExpFlags(parent2));
            if (parent2.lastIndex) child.lastIndex = parent2.lastIndex;
          } else if (clone2.__isDate(parent2)) {
            child = new Date(parent2.getTime());
          } else if (useBuffer && Buffer.isBuffer(parent2)) {
            if (Buffer.allocUnsafe) {
              child = Buffer.allocUnsafe(parent2.length);
            } else {
              child = new Buffer(parent2.length);
            }
            parent2.copy(child);
            return child;
          } else if (_instanceof(parent2, Error)) {
            child = Object.create(parent2);
          } else {
            if (typeof prototype == "undefined") {
              proto = Object.getPrototypeOf(parent2);
              child = Object.create(proto);
            } else {
              child = Object.create(prototype);
              proto = prototype;
            }
          }
          if (circular) {
            var index = allParents.indexOf(parent2);
            if (index != -1) {
              return allChildren[index];
            }
            allParents.push(parent2);
            allChildren.push(child);
          }
          if (_instanceof(parent2, nativeMap)) {
            parent2.forEach(function(value, key) {
              var keyChild = _clone(key, depth2 - 1);
              var valueChild = _clone(value, depth2 - 1);
              child.set(keyChild, valueChild);
            });
          }
          if (_instanceof(parent2, nativeSet)) {
            parent2.forEach(function(value) {
              var entryChild = _clone(value, depth2 - 1);
              child.add(entryChild);
            });
          }
          for (var i in parent2) {
            var attrs;
            if (proto) {
              attrs = Object.getOwnPropertyDescriptor(proto, i);
            }
            if (attrs && attrs.set == null) {
              continue;
            }
            child[i] = _clone(parent2[i], depth2 - 1);
          }
          if (Object.getOwnPropertySymbols) {
            var symbols = Object.getOwnPropertySymbols(parent2);
            for (var i = 0; i < symbols.length; i++) {
              var symbol = symbols[i];
              var descriptor = Object.getOwnPropertyDescriptor(parent2, symbol);
              if (descriptor && !descriptor.enumerable && !includeNonEnumerable) {
                continue;
              }
              child[symbol] = _clone(parent2[symbol], depth2 - 1);
              if (!descriptor.enumerable) {
                Object.defineProperty(child, symbol, {
                  enumerable: false
                });
              }
            }
          }
          if (includeNonEnumerable) {
            var allPropertyNames = Object.getOwnPropertyNames(parent2);
            for (var i = 0; i < allPropertyNames.length; i++) {
              var propertyName = allPropertyNames[i];
              var descriptor = Object.getOwnPropertyDescriptor(parent2, propertyName);
              if (descriptor && descriptor.enumerable) {
                continue;
              }
              child[propertyName] = _clone(parent2[propertyName], depth2 - 1);
              Object.defineProperty(child, propertyName, {
                enumerable: false
              });
            }
          }
          return child;
        }
        return _clone(parent, depth);
      }
      clone2.clonePrototype = function clonePrototype(parent) {
        if (parent === null) return null;
        var c = function() {
        };
        c.prototype = parent;
        return new c();
      };
      function __objToStr(o) {
        return Object.prototype.toString.call(o);
      }
      clone2.__objToStr = __objToStr;
      function __isDate(o) {
        return typeof o === "object" && __objToStr(o) === "[object Date]";
      }
      clone2.__isDate = __isDate;
      function __isArray(o) {
        return typeof o === "object" && __objToStr(o) === "[object Array]";
      }
      clone2.__isArray = __isArray;
      function __isRegExp(o) {
        return typeof o === "object" && __objToStr(o) === "[object RegExp]";
      }
      clone2.__isRegExp = __isRegExp;
      function __getRegExpFlags(re) {
        var flags = "";
        if (re.global) flags += "g";
        if (re.ignoreCase) flags += "i";
        if (re.multiline) flags += "m";
        return flags;
      }
      clone2.__getRegExpFlags = __getRegExpFlags;
      return clone2;
    }();
    if (typeof module === "object" && module.exports) {
      module.exports = clone;
    }
  }
});

// node_modules/events/events.js
var require_events = __commonJS({
  "node_modules/events/events.js"(exports, module) {
    "use strict";
    var R = typeof Reflect === "object" ? Reflect : null;
    var ReflectApply = R && typeof R.apply === "function" ? R.apply : function ReflectApply2(target, receiver, args) {
      return Function.prototype.apply.call(target, receiver, args);
    };
    var ReflectOwnKeys;
    if (R && typeof R.ownKeys === "function") {
      ReflectOwnKeys = R.ownKeys;
    } else if (Object.getOwnPropertySymbols) {
      ReflectOwnKeys = function ReflectOwnKeys2(target) {
        return Object.getOwnPropertyNames(target).concat(Object.getOwnPropertySymbols(target));
      };
    } else {
      ReflectOwnKeys = function ReflectOwnKeys2(target) {
        return Object.getOwnPropertyNames(target);
      };
    }
    function ProcessEmitWarning(warning) {
      if (console && console.warn) console.warn(warning);
    }
    var NumberIsNaN = Number.isNaN || function NumberIsNaN2(value) {
      return value !== value;
    };
    function EventEmitter() {
      EventEmitter.init.call(this);
    }
    module.exports = EventEmitter;
    module.exports.once = once;
    EventEmitter.EventEmitter = EventEmitter;
    EventEmitter.prototype._events = void 0;
    EventEmitter.prototype._eventsCount = 0;
    EventEmitter.prototype._maxListeners = void 0;
    var defaultMaxListeners = 10;
    function checkListener(listener) {
      if (typeof listener !== "function") {
        throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
      }
    }
    Object.defineProperty(EventEmitter, "defaultMaxListeners", {
      enumerable: true,
      get: function() {
        return defaultMaxListeners;
      },
      set: function(arg) {
        if (typeof arg !== "number" || arg < 0 || NumberIsNaN(arg)) {
          throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + ".");
        }
        defaultMaxListeners = arg;
      }
    });
    EventEmitter.init = function() {
      if (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) {
        this._events = /* @__PURE__ */ Object.create(null);
        this._eventsCount = 0;
      }
      this._maxListeners = this._maxListeners || void 0;
    };
    EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
      if (typeof n !== "number" || n < 0 || NumberIsNaN(n)) {
        throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + n + ".");
      }
      this._maxListeners = n;
      return this;
    };
    function _getMaxListeners(that) {
      if (that._maxListeners === void 0) return EventEmitter.defaultMaxListeners;
      return that._maxListeners;
    }
    EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
      return _getMaxListeners(this);
    };
    EventEmitter.prototype.emit = function emit(type) {
      var args = [];
      for (var i = 1; i < arguments.length; i++) args.push(arguments[i]);
      var doError = type === "error";
      var events = this._events;
      if (events !== void 0) doError = doError && events.error === void 0;
      else if (!doError) return false;
      if (doError) {
        var er;
        if (args.length > 0) er = args[0];
        if (er instanceof Error) {
          throw er;
        }
        var err = new Error("Unhandled error." + (er ? " (" + er.message + ")" : ""));
        err.context = er;
        throw err;
      }
      var handler = events[type];
      if (handler === void 0) return false;
      if (typeof handler === "function") {
        ReflectApply(handler, this, args);
      } else {
        var len = handler.length;
        var listeners = arrayClone(handler, len);
        for (var i = 0; i < len; ++i) ReflectApply(listeners[i], this, args);
      }
      return true;
    };
    function _addListener(target, type, listener, prepend) {
      var m;
      var events;
      var existing;
      checkListener(listener);
      events = target._events;
      if (events === void 0) {
        events = target._events = /* @__PURE__ */ Object.create(null);
        target._eventsCount = 0;
      } else {
        if (events.newListener !== void 0) {
          target.emit("newListener", type, listener.listener ? listener.listener : listener);
          events = target._events;
        }
        existing = events[type];
      }
      if (existing === void 0) {
        existing = events[type] = listener;
        ++target._eventsCount;
      } else {
        if (typeof existing === "function") {
          existing = events[type] = prepend ? [listener, existing] : [existing, listener];
        } else if (prepend) {
          existing.unshift(listener);
        } else {
          existing.push(listener);
        }
        m = _getMaxListeners(target);
        if (m > 0 && existing.length > m && !existing.warned) {
          existing.warned = true;
          var w = new Error("Possible EventEmitter memory leak detected. " + existing.length + " " + String(type) + " listeners added. Use emitter.setMaxListeners() to increase limit");
          w.name = "MaxListenersExceededWarning";
          w.emitter = target;
          w.type = type;
          w.count = existing.length;
          ProcessEmitWarning(w);
        }
      }
      return target;
    }
    EventEmitter.prototype.addListener = function addListener(type, listener) {
      return _addListener(this, type, listener, false);
    };
    EventEmitter.prototype.on = EventEmitter.prototype.addListener;
    EventEmitter.prototype.prependListener = function prependListener(type, listener) {
      return _addListener(this, type, listener, true);
    };
    function onceWrapper() {
      if (!this.fired) {
        this.target.removeListener(this.type, this.wrapFn);
        this.fired = true;
        if (arguments.length === 0) return this.listener.call(this.target);
        return this.listener.apply(this.target, arguments);
      }
    }
    function _onceWrap(target, type, listener) {
      var state = {
        fired: false,
        wrapFn: void 0,
        target,
        type,
        listener
      };
      var wrapped = onceWrapper.bind(state);
      wrapped.listener = listener;
      state.wrapFn = wrapped;
      return wrapped;
    }
    EventEmitter.prototype.once = function once2(type, listener) {
      checkListener(listener);
      this.on(type, _onceWrap(this, type, listener));
      return this;
    };
    EventEmitter.prototype.prependOnceListener = function prependOnceListener(type, listener) {
      checkListener(listener);
      this.prependListener(type, _onceWrap(this, type, listener));
      return this;
    };
    EventEmitter.prototype.removeListener = function removeListener(type, listener) {
      var list, events, position, i, originalListener;
      checkListener(listener);
      events = this._events;
      if (events === void 0) return this;
      list = events[type];
      if (list === void 0) return this;
      if (list === listener || list.listener === listener) {
        if (--this._eventsCount === 0) this._events = /* @__PURE__ */ Object.create(null);
        else {
          delete events[type];
          if (events.removeListener) this.emit("removeListener", type, list.listener || listener);
        }
      } else if (typeof list !== "function") {
        position = -1;
        for (i = list.length - 1; i >= 0; i--) {
          if (list[i] === listener || list[i].listener === listener) {
            originalListener = list[i].listener;
            position = i;
            break;
          }
        }
        if (position < 0) return this;
        if (position === 0) list.shift();
        else {
          spliceOne(list, position);
        }
        if (list.length === 1) events[type] = list[0];
        if (events.removeListener !== void 0) this.emit("removeListener", type, originalListener || listener);
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(type) {
      var listeners, events, i;
      events = this._events;
      if (events === void 0) return this;
      if (events.removeListener === void 0) {
        if (arguments.length === 0) {
          this._events = /* @__PURE__ */ Object.create(null);
          this._eventsCount = 0;
        } else if (events[type] !== void 0) {
          if (--this._eventsCount === 0) this._events = /* @__PURE__ */ Object.create(null);
          else delete events[type];
        }
        return this;
      }
      if (arguments.length === 0) {
        var keys = Object.keys(events);
        var key;
        for (i = 0; i < keys.length; ++i) {
          key = keys[i];
          if (key === "removeListener") continue;
          this.removeAllListeners(key);
        }
        this.removeAllListeners("removeListener");
        this._events = /* @__PURE__ */ Object.create(null);
        this._eventsCount = 0;
        return this;
      }
      listeners = events[type];
      if (typeof listeners === "function") {
        this.removeListener(type, listeners);
      } else if (listeners !== void 0) {
        for (i = listeners.length - 1; i >= 0; i--) {
          this.removeListener(type, listeners[i]);
        }
      }
      return this;
    };
    function _listeners(target, type, unwrap) {
      var events = target._events;
      if (events === void 0) return [];
      var evlistener = events[type];
      if (evlistener === void 0) return [];
      if (typeof evlistener === "function") return unwrap ? [evlistener.listener || evlistener] : [evlistener];
      return unwrap ? unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
    }
    EventEmitter.prototype.listeners = function listeners(type) {
      return _listeners(this, type, true);
    };
    EventEmitter.prototype.rawListeners = function rawListeners(type) {
      return _listeners(this, type, false);
    };
    EventEmitter.listenerCount = function(emitter, type) {
      if (typeof emitter.listenerCount === "function") {
        return emitter.listenerCount(type);
      } else {
        return listenerCount.call(emitter, type);
      }
    };
    EventEmitter.prototype.listenerCount = listenerCount;
    function listenerCount(type) {
      var events = this._events;
      if (events !== void 0) {
        var evlistener = events[type];
        if (typeof evlistener === "function") {
          return 1;
        } else if (evlistener !== void 0) {
          return evlistener.length;
        }
      }
      return 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
    };
    function arrayClone(arr, n) {
      var copy = new Array(n);
      for (var i = 0; i < n; ++i) copy[i] = arr[i];
      return copy;
    }
    function spliceOne(list, index) {
      for (; index + 1 < list.length; index++) list[index] = list[index + 1];
      list.pop();
    }
    function unwrapListeners(arr) {
      var ret = new Array(arr.length);
      for (var i = 0; i < ret.length; ++i) {
        ret[i] = arr[i].listener || arr[i];
      }
      return ret;
    }
    function once(emitter, name) {
      return new Promise(function(resolve, reject) {
        function errorListener(err) {
          emitter.removeListener(name, resolver);
          reject(err);
        }
        function resolver() {
          if (typeof emitter.removeListener === "function") {
            emitter.removeListener("error", errorListener);
          }
          resolve([].slice.call(arguments));
        }
        ;
        eventTargetAgnosticAddListener(emitter, name, resolver, {
          once: true
        });
        if (name !== "error") {
          addErrorHandlerIfEventEmitter(emitter, errorListener, {
            once: true
          });
        }
      });
    }
    function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
      if (typeof emitter.on === "function") {
        eventTargetAgnosticAddListener(emitter, "error", handler, flags);
      }
    }
    function eventTargetAgnosticAddListener(emitter, name, listener, flags) {
      if (typeof emitter.on === "function") {
        if (flags.once) {
          emitter.once(name, listener);
        } else {
          emitter.on(name, listener);
        }
      } else if (typeof emitter.addEventListener === "function") {
        emitter.addEventListener(name, function wrapListener(arg) {
          if (flags.once) {
            emitter.removeEventListener(name, wrapListener);
          }
          listener(arg);
        });
      } else {
        throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof emitter);
      }
    }
  }
});

// node_modules/node-cache/lib/node_cache.js
var require_node_cache = __commonJS({
  "node_modules/node-cache/lib/node_cache.js"(exports, module) {
    (function() {
      var EventEmitter, NodeCache, clone, splice = [].splice, boundMethodCheck = function(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
          throw new Error("Bound instance method accessed before binding");
        }
      }, indexOf = [].indexOf;
      clone = require_clone();
      EventEmitter = require_events().EventEmitter;
      module.exports = NodeCache = function() {
        class NodeCache2 extends EventEmitter {
          constructor(options = {}) {
            super();
            this.get = this.get.bind(this);
            this.mget = this.mget.bind(this);
            this.set = this.set.bind(this);
            this.mset = this.mset.bind(this);
            this.del = this.del.bind(this);
            this.take = this.take.bind(this);
            this.ttl = this.ttl.bind(this);
            this.getTtl = this.getTtl.bind(this);
            this.keys = this.keys.bind(this);
            this.has = this.has.bind(this);
            this.getStats = this.getStats.bind(this);
            this.flushAll = this.flushAll.bind(this);
            this.flushStats = this.flushStats.bind(this);
            this.close = this.close.bind(this);
            this._checkData = this._checkData.bind(this);
            this._check = this._check.bind(this);
            this._isInvalidKey = this._isInvalidKey.bind(this);
            this._wrap = this._wrap.bind(this);
            this._getValLength = this._getValLength.bind(this);
            this._error = this._error.bind(this);
            this._initErrors = this._initErrors.bind(this);
            this.options = options;
            this._initErrors();
            this.data = {};
            this.options = Object.assign({
              // convert all elements to string
              forceString: false,
              // used standard size for calculating value size
              objectValueSize: 80,
              promiseValueSize: 80,
              arrayValueSize: 40,
              // standard time to live in seconds. 0 = infinity;
              stdTTL: 0,
              // time in seconds to check all data and delete expired keys
              checkperiod: 600,
              // en/disable cloning of variables. If `true` you'll get a copy of the cached variable. If `false` you'll save and get just the reference
              useClones: true,
              // whether values should be deleted automatically at expiration
              deleteOnExpire: true,
              // enable legacy callbacks
              enableLegacyCallbacks: false,
              // max amount of keys that are being stored
              maxKeys: -1
            }, this.options);
            if (this.options.enableLegacyCallbacks) {
              console.warn("WARNING! node-cache legacy callback support will drop in v6.x");
              ["get", "mget", "set", "del", "ttl", "getTtl", "keys", "has"].forEach((methodKey) => {
                var oldMethod;
                oldMethod = this[methodKey];
                this[methodKey] = function(...args) {
                  var cb, err, ref, res;
                  ref = args, [...args] = ref, [cb] = splice.call(args, -1);
                  if (typeof cb === "function") {
                    try {
                      res = oldMethod(...args);
                      cb(null, res);
                    } catch (error1) {
                      err = error1;
                      cb(err);
                    }
                  } else {
                    return oldMethod(...args, cb);
                  }
                };
              });
            }
            this.stats = {
              hits: 0,
              misses: 0,
              keys: 0,
              ksize: 0,
              vsize: 0
            };
            this.validKeyTypes = ["string", "number"];
            this._checkData();
            return;
          }
          get(key) {
            var _ret, err;
            boundMethodCheck(this, NodeCache2);
            if ((err = this._isInvalidKey(key)) != null) {
              throw err;
            }
            if (this.data[key] != null && this._check(key, this.data[key])) {
              this.stats.hits++;
              _ret = this._unwrap(this.data[key]);
              return _ret;
            } else {
              this.stats.misses++;
              return void 0;
            }
          }
          mget(keys) {
            var _err, err, i, key, len, oRet;
            boundMethodCheck(this, NodeCache2);
            if (!Array.isArray(keys)) {
              _err = this._error("EKEYSTYPE");
              throw _err;
            }
            oRet = {};
            for (i = 0, len = keys.length; i < len; i++) {
              key = keys[i];
              if ((err = this._isInvalidKey(key)) != null) {
                throw err;
              }
              if (this.data[key] != null && this._check(key, this.data[key])) {
                this.stats.hits++;
                oRet[key] = this._unwrap(this.data[key]);
              } else {
                this.stats.misses++;
              }
            }
            return oRet;
          }
          set(key, value, ttl) {
            var _err, err, existent;
            boundMethodCheck(this, NodeCache2);
            if (this.options.maxKeys > -1 && this.stats.keys >= this.options.maxKeys) {
              _err = this._error("ECACHEFULL");
              throw _err;
            }
            if (this.options.forceString && false === "string") {
              value = JSON.stringify(value);
            }
            if (ttl == null) {
              ttl = this.options.stdTTL;
            }
            if ((err = this._isInvalidKey(key)) != null) {
              throw err;
            }
            existent = false;
            if (this.data[key]) {
              existent = true;
              this.stats.vsize -= this._getValLength(this._unwrap(this.data[key], false));
            }
            this.data[key] = this._wrap(value, ttl);
            this.stats.vsize += this._getValLength(value);
            if (!existent) {
              this.stats.ksize += this._getKeyLength(key);
              this.stats.keys++;
            }
            this.emit("set", key, value);
            return true;
          }
          mset(keyValueSet) {
            var _err, err, i, j, key, keyValuePair, len, len1, ttl, val;
            boundMethodCheck(this, NodeCache2);
            if (this.options.maxKeys > -1 && this.stats.keys + keyValueSet.length >= this.options.maxKeys) {
              _err = this._error("ECACHEFULL");
              throw _err;
            }
            for (i = 0, len = keyValueSet.length; i < len; i++) {
              keyValuePair = keyValueSet[i];
              ({
                key,
                val,
                ttl
              } = keyValuePair);
              if (ttl && typeof ttl !== "number") {
                _err = this._error("ETTLTYPE");
                throw _err;
              }
              if ((err = this._isInvalidKey(key)) != null) {
                throw err;
              }
            }
            for (j = 0, len1 = keyValueSet.length; j < len1; j++) {
              keyValuePair = keyValueSet[j];
              ({
                key,
                val,
                ttl
              } = keyValuePair);
              this.set(key, val, ttl);
            }
            return true;
          }
          del(keys) {
            var delCount, err, i, key, len, oldVal;
            boundMethodCheck(this, NodeCache2);
            if (!Array.isArray(keys)) {
              keys = [keys];
            }
            delCount = 0;
            for (i = 0, len = keys.length; i < len; i++) {
              key = keys[i];
              if ((err = this._isInvalidKey(key)) != null) {
                throw err;
              }
              if (this.data[key] != null) {
                this.stats.vsize -= this._getValLength(this._unwrap(this.data[key], false));
                this.stats.ksize -= this._getKeyLength(key);
                this.stats.keys--;
                delCount++;
                oldVal = this.data[key];
                delete this.data[key];
                this.emit("del", key, oldVal.v);
              }
            }
            return delCount;
          }
          take(key) {
            var _ret;
            boundMethodCheck(this, NodeCache2);
            _ret = this.get(key);
            if (_ret != null) {
              this.del(key);
            }
            return _ret;
          }
          ttl(key, ttl) {
            var err;
            boundMethodCheck(this, NodeCache2);
            ttl || (ttl = this.options.stdTTL);
            if (!key) {
              return false;
            }
            if ((err = this._isInvalidKey(key)) != null) {
              throw err;
            }
            if (this.data[key] != null && this._check(key, this.data[key])) {
              if (ttl >= 0) {
                this.data[key] = this._wrap(this.data[key].v, ttl, false);
              } else {
                this.del(key);
              }
              return true;
            } else {
              return false;
            }
          }
          getTtl(key) {
            var _ttl, err;
            boundMethodCheck(this, NodeCache2);
            if (!key) {
              return void 0;
            }
            if ((err = this._isInvalidKey(key)) != null) {
              throw err;
            }
            if (this.data[key] != null && this._check(key, this.data[key])) {
              _ttl = this.data[key].t;
              return _ttl;
            } else {
              return void 0;
            }
          }
          keys() {
            var _keys;
            boundMethodCheck(this, NodeCache2);
            _keys = Object.keys(this.data);
            return _keys;
          }
          has(key) {
            var _exists;
            boundMethodCheck(this, NodeCache2);
            _exists = this.data[key] != null && this._check(key, this.data[key]);
            return _exists;
          }
          getStats() {
            boundMethodCheck(this, NodeCache2);
            return this.stats;
          }
          flushAll(_startPeriod = true) {
            boundMethodCheck(this, NodeCache2);
            this.data = {};
            this.stats = {
              hits: 0,
              misses: 0,
              keys: 0,
              ksize: 0,
              vsize: 0
            };
            this._killCheckPeriod();
            this._checkData(_startPeriod);
            this.emit("flush");
          }
          flushStats() {
            boundMethodCheck(this, NodeCache2);
            this.stats = {
              hits: 0,
              misses: 0,
              keys: 0,
              ksize: 0,
              vsize: 0
            };
            this.emit("flush_stats");
          }
          close() {
            boundMethodCheck(this, NodeCache2);
            this._killCheckPeriod();
          }
          _checkData(startPeriod = true) {
            var key, ref, value;
            boundMethodCheck(this, NodeCache2);
            ref = this.data;
            for (key in ref) {
              value = ref[key];
              this._check(key, value);
            }
            if (startPeriod && this.options.checkperiod > 0) {
              this.checkTimeout = setTimeout(this._checkData, this.options.checkperiod * 1e3, startPeriod);
              if (this.checkTimeout != null && this.checkTimeout.unref != null) {
                this.checkTimeout.unref();
              }
            }
          }
          // ## _killCheckPeriod
          // stop the checkdata period. Only needed to abort the script in testing mode.
          _killCheckPeriod() {
            if (this.checkTimeout != null) {
              return clearTimeout(this.checkTimeout);
            }
          }
          _check(key, data) {
            var _retval;
            boundMethodCheck(this, NodeCache2);
            _retval = true;
            if (data.t !== 0 && data.t < Date.now()) {
              if (this.options.deleteOnExpire) {
                _retval = false;
                this.del(key);
              }
              this.emit("expired", key, this._unwrap(data));
            }
            return _retval;
          }
          _isInvalidKey(key) {
            var ref;
            boundMethodCheck(this, NodeCache2);
            if (ref = typeof key, indexOf.call(this.validKeyTypes, ref) < 0) {
              return this._error("EKEYTYPE", {
                type: typeof key
              });
            }
          }
          _wrap(value, ttl, asClone = true) {
            var livetime, now, oReturn, ttlMultiplicator;
            boundMethodCheck(this, NodeCache2);
            if (!this.options.useClones) {
              asClone = false;
            }
            now = Date.now();
            livetime = 0;
            ttlMultiplicator = 1e3;
            if (ttl === 0) {
              livetime = 0;
            } else if (ttl) {
              livetime = now + ttl * ttlMultiplicator;
            } else {
              if (this.options.stdTTL === 0) {
                livetime = this.options.stdTTL;
              } else {
                livetime = now + this.options.stdTTL * ttlMultiplicator;
              }
            }
            return oReturn = {
              t: livetime,
              v: asClone ? clone(value) : value
            };
          }
          // ## _unwrap
          // internal method to extract get the value out of the wrapped value
          _unwrap(value, asClone = true) {
            if (!this.options.useClones) {
              asClone = false;
            }
            if (value.v != null) {
              if (asClone) {
                return clone(value.v);
              } else {
                return value.v;
              }
            }
            return null;
          }
          // ## _getKeyLength
          // internal method the calculate the key length
          _getKeyLength(key) {
            return key.toString().length;
          }
          _getValLength(value) {
            boundMethodCheck(this, NodeCache2);
            if (typeof value === "string") {
              return value.length;
            } else if (this.options.forceString) {
              return JSON.stringify(value).length;
            } else if (Array.isArray(value)) {
              return this.options.arrayValueSize * value.length;
            } else if (typeof value === "number") {
              return 8;
            } else if (typeof (value != null ? value.then : void 0) === "function") {
              return this.options.promiseValueSize;
            } else if (typeof Buffer !== "undefined" && Buffer !== null ? Buffer.isBuffer(value) : void 0) {
              return value.length;
            } else if (value != null && typeof value === "object") {
              return this.options.objectValueSize * Object.keys(value).length;
            } else if (typeof value === "boolean") {
              return 8;
            } else {
              return 0;
            }
          }
          _error(type, data = {}) {
            var error;
            boundMethodCheck(this, NodeCache2);
            error = new Error();
            error.name = type;
            error.errorcode = type;
            error.message = this.ERRORS[type] != null ? this.ERRORS[type](data) : "-";
            error.data = data;
            return error;
          }
          _initErrors() {
            var _errMsg, _errT, ref;
            boundMethodCheck(this, NodeCache2);
            this.ERRORS = {};
            ref = this._ERRORS;
            for (_errT in ref) {
              _errMsg = ref[_errT];
              this.ERRORS[_errT] = this.createErrorMessage(_errMsg);
            }
          }
          createErrorMessage(errMsg) {
            return function(args) {
              return errMsg.replace("__key", args.type);
            };
          }
        }
        ;
        NodeCache2.prototype._ERRORS = {
          "ENOTFOUND": "Key `__key` not found",
          "ECACHEFULL": "Cache max keys amount exceeded",
          "EKEYTYPE": "The key argument has to be of type `string` or `number`. Found: `__key`",
          "EKEYSTYPE": "The keys argument has to be an array.",
          "ETTLTYPE": "The ttl argument has to be a number."
        };
        return NodeCache2;
      }.call(this);
    }).call(exports);
  }
});

// node_modules/node-cache/index.js
var require_node_cache2 = __commonJS({
  "node_modules/node-cache/index.js"(exports, module) {
    (function() {
      var exports2;
      exports2 = module.exports = require_node_cache();
      exports2.version = "5.1.2";
    }).call(exports);
  }
});
export default require_node_cache2();
//# sourceMappingURL=node-cache.js.map
